#!/bin/bash
java -jar ~/bin/onebusaway-gtfs-transformer-cli-5.0.0.jar --transform=transform.txt GTFS.zip GTFS_sbahn_berlin
#rm GTFS_sbahn_berlin/shapes.txt
zip -j GTFS_sbahn_berlin.zip GTFS_sbahn_berlin/*
